
## Endpoints for Cybersecurity resilience maturity assessment of CNII project


- [PostMan Documentation](https://documenter.getpostman.com/view/10675211/UVeNkMpM#91c976bd-78e1-405e-b603-07f58e22de3f).

